class ParkingCard{
	public cardNo : string;

	constructor(){
        this.cardNo =Math.ceil(Math.random()*10).toString(); 
	}

    public equals(parkingCard : ParkingCard) : boolean{
    	if(parkingCard.cardNo === this.cardNo){
    		return true;
    	}
    	return false;
    }
}

class Car{
    constructor(public carNo: string){
    	this.carNo = carNo;
    }

    public equals(car : Car) : boolean{
        if(this.carNo === car.carNo)return true;
        return false;
    }
}

class ParkingLot{
    private parkingSpace:number;
    private parkingName:string;
    private parkedCars:{[key:string] : Car} = null;

    constructor(name : string,parkingSpace : number){
    	this.parkingName = name;
    	this.parkingSpace = parkingSpace;
    }

    public getParkingSpace(): number{
    	return this.parkingSpace;
    }

    public getParkingCarsNum(): number{
    	let count = 0;
    	for(let i in this.parkedCars){ count++; }
    	return count;
    }

    public park(car : Car) : ParkingCard{
    	console.log(car);
		let card = new ParkingCard();
		console.log(card);
		this.parkedCars[card.cardNo] = car;
		return card;
	}

	hasThisCar(car : Car) : boolean{
		for(let card in this.parkedCars){
			if(this.parkedCars[card].equals(car)) return true;
		}
		return 	false;
	}

	public pick(card : ParkingCard ) :  Car{
		let car = this.parkedCars[card.cardNo];
		if(car) this.parkedCars[card.cardNo] == null;
		return car;
	}

    public isParkingLotFull() : boolean{
		return this.getParkingCarsNum() == this.parkingSpace;
	}

	public getRemainSpace() : number{
		return this.parkingSpace - this.getParkingCarsNum();
	}
}

class ParkingBoy{
	protected parkingLots:Array<ParkingLot>;

    public setParkingLots(parkingLots : ParkingLot[]) : void{
		this.parkingLots = parkingLots;
	}

	 protected hasThisCar(car : Car) : boolean{
		for(let parkingLot of this.parkingLots ) {
			if(parkingLot.hasThisCar(car)) {
				return true;
			}
		}
		return false;
	}

	public park(car :  Car) : ParkingCard{
         if(!this.hasThisCar(car)){
         	return this.getFirstParkingLotIsNotFull().park(car);
         }
         return null;
    }

	public pick(card : ParkingCard) : Car{
		let car = null;
		for(let lot of this.parkingLots) {
			car = lot.pick(card);
			if(car != null) {
				return car;
			}
		}
	}

	private getFirstParkingLotIsNotFull() : ParkingLot{
		for (let parkingLot of this.parkingLots) {
			if(!parkingLot.isParkingLotFull()) {
				return parkingLot;
			}
		}
		throw "parkinglot is full";
	}
}

class Company{
	private parkingLots:Array<ParkingLot> = [];
	
	public getParkingLotSize() : number{
         return this.parkingLots.length;
	}

    public addLot(parkingLot : ParkingLot) : void{
    	this.parkingLots.push(parkingLot);
    }

    public employ(parkingBoy : ParkingBoy) : void{
    	parkingBoy.setParkingLots(this.parkingLots);
    }
   
}

let company = new Company();
let parkingLot = new ParkingLot("1", 2);
let parkingBoy = new ParkingBoy();
company.addLot(parkingLot);
company.employ(parkingBoy);
let car1 = new Car("1");
let car2 = new Car("2");
let card = null;
setTimeout(()=>{
	card = parkingBoy.park(car1);
	console.log(card);
    console.log(`the boy has parked a car in the lot`);
    console.log(`there ` + parkingLot.getParkingCarsNum() + " cars in the lot");
    setTimeout(()=>{
	parkingBoy.park(car2);
    console.log(`the boy has parked a car in the lot`);
    console.log(`there ` + parkingLot.getParkingCarsNum() + " cars in the lot");
    setTimeout(()=>{
	parkingBoy.pick(card);
    console.log(`the boy has pick a car from the lot`);
    console.log(`there ` + parkingLot.getParkingCarsNum() + " in the lot");
    }, 1000)       
    }, 1000)
}, 1000)










