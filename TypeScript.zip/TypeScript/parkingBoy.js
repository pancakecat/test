var ParkingCard = /** @class */ (function () {
    function ParkingCard() {
        this.cardNo = Math.ceil(Math.random() * 10).toString();
    }
    ParkingCard.prototype.equals = function (parkingCard) {
        if (parkingCard.cardNo === this.cardNo) {
            return true;
        }
        return false;
    };
    return ParkingCard;
}());
var Car = /** @class */ (function () {
    function Car(carNo) {
        this.carNo = carNo;
        this.carNo = carNo;
    }
    Car.prototype.equals = function (car) {
        if (this.carNo === car.carNo)
            return true;
        return false;
    };
    return Car;
}());
var ParkingLot = /** @class */ (function () {
    function ParkingLot(name, parkingSpace) {
        this.parkedCars = null;
        this.parkingName = name;
        this.parkingSpace = parkingSpace;
    }
    ParkingLot.prototype.getParkingSpace = function () {
        return this.parkingSpace;
    };
    ParkingLot.prototype.getParkingCarsNum = function () {
        var count = 0;
        for (var i in this.parkedCars) {
            count++;
        }
        return count;
    };
    ParkingLot.prototype.park = function (car) {
        console.log(car);
        var card = new ParkingCard();
        console.log(card);
        this.parkedCars[card.cardNo] = car;
        return card;
    };
    ParkingLot.prototype.hasThisCar = function (car) {
        for (var card_1 in this.parkedCars) {
            if (this.parkedCars[card_1].equals(car))
                return true;
        }
        return false;
    };
    ParkingLot.prototype.pick = function (card) {
        var car = this.parkedCars[card.cardNo];
        if (car)
            this.parkedCars[card.cardNo] == null;
        return car;
    };
    ParkingLot.prototype.isParkingLotFull = function () {
        return this.getParkingCarsNum() == this.parkingSpace;
    };
    ParkingLot.prototype.getRemainSpace = function () {
        return this.parkingSpace - this.getParkingCarsNum();
    };
    return ParkingLot;
}());
var ParkingBoy = /** @class */ (function () {
    function ParkingBoy() {
    }
    ParkingBoy.prototype.setParkingLots = function (parkingLots) {
        this.parkingLots = parkingLots;
    };
    ParkingBoy.prototype.hasThisCar = function (car) {
        for (var _i = 0, _a = this.parkingLots; _i < _a.length; _i++) {
            var parkingLot_1 = _a[_i];
            if (parkingLot_1.hasThisCar(car)) {
                return true;
            }
        }
        return false;
    };
    ParkingBoy.prototype.park = function (car) {
        if (!this.hasThisCar(car)) {
            return this.getFirstParkingLotIsNotFull().park(car);
        }
        return null;
    };
    ParkingBoy.prototype.pick = function (card) {
        var car = null;
        for (var _i = 0, _a = this.parkingLots; _i < _a.length; _i++) {
            var lot = _a[_i];
            car = lot.pick(card);
            if (car != null) {
                return car;
            }
        }
    };
    ParkingBoy.prototype.getFirstParkingLotIsNotFull = function () {
        for (var _i = 0, _a = this.parkingLots; _i < _a.length; _i++) {
            var parkingLot_2 = _a[_i];
            if (!parkingLot_2.isParkingLotFull()) {
                return parkingLot_2;
            }
        }
        throw "parkinglot is full";
    };
    return ParkingBoy;
}());
var Company = /** @class */ (function () {
    function Company() {
        this.parkingLots = [];
    }
    Company.prototype.getParkingLotSize = function () {
        return this.parkingLots.length;
    };
    Company.prototype.addLot = function (parkingLot) {
        this.parkingLots.push(parkingLot);
    };
    Company.prototype.employ = function (parkingBoy) {
        parkingBoy.setParkingLots(this.parkingLots);
    };
    return Company;
}());
var company = new Company();
var parkingLot = new ParkingLot("1", 2);
var parkingBoy = new ParkingBoy();
company.addLot(parkingLot);
company.employ(parkingBoy);
var car1 = new Car("1");
var car2 = new Car("2");
var card = null;
setTimeout(function () {
    card = parkingBoy.park(car1);
    console.log(card);
    console.log("the boy has parked a car in the lot");
    console.log("there " + parkingLot.getParkingCarsNum() + " cars in the lot");
    setTimeout(function () {
        parkingBoy.park(car2);
        console.log("the boy has parked a car in the lot");
        console.log("there " + parkingLot.getParkingCarsNum() + " cars in the lot");
        setTimeout(function () {
            parkingBoy.pick(card);
            console.log("the boy has pick a car from the lot");
            console.log("there " + parkingLot.getParkingCarsNum() + " in the lot");
        }, 1000);
    }, 1000);
}, 1000);
